import React from "react";

const NotFound = () => {

  return (

    <div className='notfound-image'>
      <div className='landing-nav'>
      </div>
    </div>

  );
};

export default NotFound;