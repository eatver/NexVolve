const User = require('./User');
const Service = require('./Service');

module.exports = { User, Service };
